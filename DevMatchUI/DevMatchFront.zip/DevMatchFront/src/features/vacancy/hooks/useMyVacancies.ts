import { useQuery } from "@tanstack/react-query";
import { getMyVacancies, type Vacancy } from "../../../api/vacancy";

// Fetch vacancies created by current user
export function useMyVacancies() {
  return useQuery<Vacancy[]>({
    queryKey: ["vacancies", "mine"],
    queryFn: getMyVacancies,
  });
}
